// declare as part of a synthesizer package
package synthesizer;

// import Iterator package
import java.util.Iterator;

public abstract class AbstractBoundedQueue<T> implements BoundedQueue<T> {
	protected int fillCount;
	protected int capacity;

	// return the size of buffer
	public int capacity() {
		return capacity;
	}

	// return the number of items in the buffer
	public int fillCount() {
		return fillCount;
	}

	// is the buffer empty?
	public boolean isEmpty() {
		if(this.fillCount() == 0) {
			return true;
		}
		return false;
	}

	// is the buffer full?
	public boolean isFull() {
		if(this.fillCount() == this.capacity()) {
			return true;
		}
		return false;
	}

	// Belows are inherited by interface BoundedQueue<T>
	public abstract T peek();
	public abstract T dequeue();
	public abstract void enqueue(T x);
	public abstract Iterator<T> iterator();

}