package lab8;

public class MagicWord8 {
    public static String magicWord() {
        /* replace magicWord with the magic word or use "early"
        *  if you are submitting early */
        String magicWord = "naptime";
        return magicWord;
    }
} 
