package hw2;                       

import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import java.lang.IndexOutOfBoundsException;
import java.lang.IllegalArgumentException;

public class Percolation {
    // create class of each grid
    public class eachGrid {
        private boolean isOpen;
        private boolean isFull;
        private int index;

        public eachGrid() {
        	isOpen = false;
        	isFull = false;
        }
    }

    private static eachGrid[][] grid;
    private static eachGrid top;
    private static eachGrid bottom;
    private static int numberOfOpenSites;

    WeightedQuickUnionUF union;

    // create N-by-N grid, with all sites initially blocked
    public Percolation(int N) {
        union = new WeightedQuickUnionUF(N * N + 2);
        grid = new eachGrid[N][];
        for(int i = 0; i < N; i++) {
        	grid[i] = new eachGrid[N];
        	for(int j = 0; j < N; j++) {
                grid[i][j] = new eachGrid();
        		grid[i][j].index = (N * i) + j;
        	}
        }

        top = new eachGrid();
        top.index = N * N;
        for(int i = 0; i < N; i++) {
        	top.isFull = true;
        	union.union(top.index, grid[0][i].index);
        }

        bottom = new eachGrid();
        bottom.index = N * N + 1;
        for(int i = 0; i < N; i++) {
        	union.union(grid[N - 1][i].index, bottom.index);
        }

        numberOfOpenSites = 0;
    }

    // open the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (row < 0 || col < 0) {
            throw new IndexOutOfBoundsException();
        } else if (row >= grid.length || col >= grid[0].length) {
        	throw new IllegalArgumentException();
        } else if (! isOpen(row, col)) {
        	grid[row][col].isOpen = true;
        	numberOfOpenSites += 1;

        	// make connection between neighbors
        	// maybe occur exception -> does it cause operation forced to be terminated?  maybe not
        	makeConnection(row, col);

        } else {
        	return ;
        }
    }

    private void makeConnection(int row, int col) {
    	if (row - 1 >= 0 && isOpen(row - 1, col) && ! union.connected(grid[row][col].index, grid[row - 1][col].index)) {
        	union.union(grid[row][col].index, grid[row - 1][col].index);
        }
        if (row + 1 <= grid.length - 1 && isOpen(row + 1, col) && ! union.connected(grid[row][col].index, grid[row + 1][col].index)) {
        	union.union(grid[row][col].index, grid[row + 1][col].index);
        }
        if (col - 1 >= 0 && isOpen(row, col - 1) && ! union.connected(grid[row][col].index, grid[row][col - 1].index)) {
        	union.union(grid[row][col].index, grid[row][col - 1].index);
        }
        if (col + 1 <= grid[0].length - 1 && isOpen(row, col + 1) && ! union.connected(grid[row][col].index, grid[row][col + 1].index)) {
        	union.union(grid[row][col].index, grid[row][col + 1].index);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (row < 0 || col < 0) {
            throw new IndexOutOfBoundsException();
        } else if (row >= grid.length || col >= grid[0].length) {
        	throw new IllegalArgumentException();
        } else {
        	return grid[row][col].isOpen;
        }
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (row < 0 || col < 0) {
            throw new IndexOutOfBoundsException();
        } else if (row >= grid.length || col >= grid[0].length) {
        	throw new IllegalArgumentException();
        } else {
        	if (union.connected(top.index, grid[row][col].index) && grid[row][col].isOpen) {
                if (row != 0 && ! checkFulled(row, col)) {
                    return grid[row][col].isFull;
                }
        		grid[row][col].isFull = true;
        		return grid[row][col].isFull;
        	}
        	return grid[row][col].isFull;
        }
    }

    // check whether there is fulled neighbor around one
    // we can filter which is real fulled one or not
    private boolean checkFulled(int row, int col) {
        if (row - 1 >= 0) {
            if (grid[row - 1][col].isFull) {
                return true;
            }
        }
        if (row + 1 <= grid.length - 1) {
            if (grid[row + 1][col].isFull) {
                return true;
            }
        }
        if (col - 1 >= 0) {
            if (grid[row][col - 1].isFull) {
                return true;
            }
        }
        if (col + 1 <= grid[0].length - 1) {
            if(grid[row][col + 1].isFull) {
                return true;
            }
        }
        return false;
    }

    // number of open sites
    public int numberOfOpenSites() {
        return numberOfOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        if (union.connected(top.index, bottom.index)) {
        	return true;
        } else {
        	return false;
        }
    }

    public static void main(String[] args) {

    }
}                       
